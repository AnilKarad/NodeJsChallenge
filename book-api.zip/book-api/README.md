# Book Management RESTful API

This is a Node.js RESTful API for managing books with CRUD (Create, Read, Update, Delete) operations. It uses MongoDB for data storage and provides a set of endpoints to interact with the book data.

## Getting Started

These instructions will help you set up and run the application locally on your machine.

### Prerequisites

Before you begin, make sure you have the following installed:

- Node.js: [Download and Install Node.js](https://nodejs.org/)
- MongoDB: [Download and Install MongoDB](https://www.mongodb.com/try/download/community)

### Installation

1. Clone the repository to your local machine:

   ```bash
   git clone https://github.com/AnilKarad/book-api.git
   
2. Navigate to the project directory:
 cd book-management-api

3. Install the project dependencies:
 npm install

4. Configuration
Create a .env file in the root of your project to set up your environment variables. Include your MongoDB connection URI and a preferred port:
 MONGODB_URI=mongodb://localhost:27017/book-api
 PORT=3000

5. Running the Application
 Start the Node.js server:
 npm start

The API will be accessible at http://localhost:3000/api/books (or the port you specified in the .env file).


6. API Endpoints and Usage
Create a new book:

Send a POST request to http://localhost:3000/api/books with a JSON body like this:
{
  "title": "Book Title",
  "author": "Author Name",
  "summary": "Book Summary"
}
View a list of all books:

Send a GET request to http://localhost:3000/api/books.

View details of a specific book by its ID:

Send a GET request to http://localhost:3000/api/books/:id, where :id is the book's unique ID.

Update a book's details:

Send a PUT request to http://localhost:3000/api/books/:id, where :id is the book's unique ID. Provide a JSON body with updated book information.

Delete a book:

Send a DELETE request to http://localhost:3000/api/books/:id, where :id is the book's unique ID.

7. Assumptions and Decisions
This project assumes that you have Node.js and MongoDB installed and properly configured.
The project uses Express.js as the web server framework and Mongoose as the MongoDB ORM.
The API is designed to manage book data with a title, author, and summary.
Feel free to modify and extend this project according to your specific requirements.

Author:
Anil Karad