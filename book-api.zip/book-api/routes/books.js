// routes/books.js
const express = require('express');
const router = express.Router();
const Book = require('../models/Book');

// Create a new book
router.post('/', async (req, res) => {
  const { title, author, summary } = req.body;
  const book = new Book({ title, author, summary });

  try {
    const savedBook = await book.save();
    res.json(savedBook);
  } catch (error) {
    res.status(500).json({ error: 'Unable to create a book' });
  }
});

// Get a list of all books
router.get('/', async (req, res) => {
  const books = await Book.find();
  res.json(books);
});

// Get details of a specific book by its ID
router.get('/:id', async (req, res) => {
  const book = await Book.findById(req.params.id);
  if (!book) {
    return res.status(404).json({ error: 'Book not found' });
  }
  res.json(book);
});

// Update a book's details
router.put('/:id', async (req, res) => {
  const { title, author, summary } = req.body;
  try {
    const updatedBook = await Book.findByIdAndUpdate(
      req.params.id,
      { title, author, summary },
      { new: true }
    );
    if (!updatedBook) {
      return res.status(404).json({ error: 'Book not found' });
    }
    res.json(updatedBook);
  } catch (error) {
    res.status(500).json({ error: 'Unable to update the book' });
  }
});

// Delete a book
router.delete('/:id', async (req, res) => {
  const result = await Book.findByIdAndDelete(req.params.id);
  if (!result) {
    return res.status(404).json({ error: 'Book not found' });
  }
  res.json({ message: 'Book deleted successfully' });
});

module.exports = router;
